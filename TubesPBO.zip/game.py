import pygame
import time
import random
pygame.font.init()
pygame.mixer.init()

lebar, tinggi = 750, 710
Layar = pygame.display.set_mode((lebar, tinggi))

#lagu
pygame.mixer.music.load("aset/audio/naruto.wav")
pygame.mixer.music.play(5, 0.0)
pygame.mixer.music.set_volume(0.15)
suara_tembak =  pygame.mixer.Sound("aset/audio/pew.wav")
suara_musuh = pygame.mixer.Sound("aset/audio/ugh.wav")

# gambar musuh
kaguya = pygame.image.load("aset/gambar/kaguya.png")
madara = pygame.image.load("aset/gambar/madara.png")
obito = pygame.image.load("aset/gambar/obito.png")
zetsu = pygame.image.load("aset/gambar/zetsu.png")



# gambar pesawat
Pesawat_pemain = pygame.image.load("aset/gambar/pes.png")

# oeluru
peluru_pemain = pygame.image.load("aset/gambar/peluru.png")

# latar belakang
latar_belakang = pygame.image.load("aset/gambar/lb.png")

class Peluru:
    def __init__(self, x, y, gambar):
        self.x = x
        self.y = y
        self.gambar = gambar
        self.mask = pygame.mask.from_surface(self.gambar)

    def cetak(self, layar):
        layar.blit(self.gambar, (self.x, self.y))

    def move(self, kecepatan_gerak):
        self.y += kecepatan_gerak

    def keluar_layar(self, height):
        return not(self.y <= height and self.y >= 0)

    def tabrakan(self, obj):
        return menabrak(self, obj)


class Pesawat:
    Durasi = 30

    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.gambar_pesawat = None
        self.gambar_peluru = None
        self.a_peluru = []
        self.penghitung_durasi = 0

    def cetak(self, layar):
        layar.blit(self.gambar_pesawat, (self.x, self.y))
        for peluru in self.a_peluru:
            peluru.cetak(layar)

    def gerakan_peluru(self, kecepatan_gerak, obj):
        self.durasi()
        for peluru in self.a_peluru:
            peluru.move(kecepatan_gerak)
            if peluru.keluar_layar(tinggi):
                self.a_peluru.remove(peluru)
            elif peluru.tabrakan(obj):
                self.a_peluru.remove(peluru)

    def durasi(self):
        if self.penghitung_durasi >= self.Durasi:
            self.penghitung_durasi = 0
        elif self.penghitung_durasi > 0:
            self.penghitung_durasi += 1

    def tembak(self):
        if self.penghitung_durasi == 0:
            peluru = Peluru(self.x, self.y, self.gambar_peluru)
            self.a_peluru.append(peluru)
            self.penghitung_durasi = 1

    def get_width(self):
        return self.gambar_pesawat.get_width()

    def get_height(self):
        return self.gambar_pesawat.get_height()


class Pemain(Pesawat):
    def __init__(self, x, y):
        super().__init__(x, y)
        self.gambar_pesawat = Pesawat_pemain
        self.gambar_peluru = peluru_pemain
        self.mask = pygame.mask.from_surface(self.gambar_pesawat)

    def gerakan_peluru(self, kecepatan_gerak, objek):
        self.durasi()
        for peluru in self.a_peluru:
            peluru.move(kecepatan_gerak)
            if peluru.keluar_layar(tinggi):
                self.a_peluru.remove(peluru)
            else:
                for obj in objek:
                    if peluru.tabrakan(obj):
                        objek.remove(obj)
                        suara_musuh.play()
                        if peluru in self.a_peluru:
                            self.a_peluru.remove(peluru)
                            

    def cetak(self, layar):
        super().cetak(layar)
       


class Musuh(Pesawat):
    varian_musuh = {
                "kaguya": (kaguya),
                "zetsu": (zetsu),
                "madara": (madara),
                "obito": (obito)
                }

    def __init__(self, x, y, jenis_musuh):
        super().__init__(x, y)
        self.gambar_pesawat = self.varian_musuh[jenis_musuh]
        self.mask = pygame.mask.from_surface(self.gambar_pesawat)

    def move(self, kecepatan_gerak):
        self.y += kecepatan_gerak



def menabrak(obj1, obj2):
    sumbu_x = obj2.x - obj1.x
    sumbu_y = obj2.y - obj1.y
    return obj1.mask.overlap(obj2.mask, (sumbu_x, sumbu_y)) != None

def main():
    mulai = True
    FPS = 60
    tingkatan = 0
    nyawa = 5
    font_utama = pygame.font.SysFont("comicsans", 50)
    font_kalah = pygame.font.SysFont("comicsans", 60)

    musuh2 = []
    gelombang_musuh = 5
    kecepatan_gerak_musuh = 1

    kecepatan_gerak_pemain = 5
    kecepatan_gerak_peluru = 5

    pemain = Pemain(300, 630)

    waktu = pygame.time.Clock()

    kalah = False
    nyawa_habis = 0

    def pengambaran_layar():
        Layar.blit(latar_belakang, (0,0))
        label_nyawa = font_utama.render(f"nyawa: {nyawa}", 1, (255,255,255))
        label_tingkatan = font_utama.render(f"tingkatan: {tingkatan}", 1, (255,255,255))

        Layar.blit(label_nyawa, (10, 10))
        Layar.blit(label_tingkatan, (lebar - label_tingkatan.get_width() - 10, 10))

        for musuh in musuh2:
            musuh.cetak(Layar)

        pemain.cetak(Layar)

        if kalah:
            label_kalah = font_kalah.render("kamu kalah!!", 1, (255,255,255))
            Layar.blit(label_kalah, (lebar/2 - label_kalah.get_width()/2, 350))

        pygame.display.update()

    while mulai:
        waktu.tick(FPS)
        pengambaran_layar()

        if nyawa <= 0:
            kalah = True
            nyawa_habis += 1

        if kalah:
            if nyawa_habis > FPS * 3:
                mulai = False
            else:
               continue

        if len(musuh2) == 0:
            tingkatan += 1
            gelombang_musuh += 10
            for i in range(gelombang_musuh):
                musuh = Musuh(random.randrange(50, lebar-100), random.randrange(-1500, -100), random.choice(["zetsu","kaguya","madara","obito"]))
                musuh2.append(musuh)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit()

        tombol = pygame.key.get_pressed()
        if tombol[pygame.K_a] and pemain.x - kecepatan_gerak_pemain > 0: 
            pemain.x -= kecepatan_gerak_pemain
        if tombol[pygame.K_d] and pemain.x + kecepatan_gerak_pemain + pemain.get_width() < lebar: 
            pemain.x += kecepatan_gerak_pemain
        if tombol[pygame.K_SPACE]:
            pemain.tembak()
            suara_tembak.play()
        if tombol[pygame.K_ESCAPE]:
            mulai= False

        for musuh in musuh2[:]:
            musuh.move(kecepatan_gerak_musuh)
            if musuh.y + musuh.get_height() > tinggi:
                nyawa -= 1
                musuh2.remove(musuh)

        pemain.gerakan_peluru(-kecepatan_gerak_peluru, musuh2)

def main_menu():
    font_judul = pygame.font.SysFont("comicsans", 70)
    mulai = True
    while mulai:
        Layar.blit(latar_belakang, (0,0))
        label_judul = font_judul.render("Tekan mouse untuk bermain", 1, (255,255,255))
        Layar.blit(label_judul, (lebar/2 - label_judul.get_width()/2, 350))
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                mulai = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                main()
    pygame.quit()
main_menu()
